import { Injectable } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { CanActivate, Router } from '@angular/router'

@Injectable()
export class LoggedInAuthGuard implements CanActivate{
    
    constructor(private _authService: AuthService, private _router: Router){}
    
    canActivate() {
        //TODO check if user is logged in or not
        if(this._authService.isLoggedIn())
        {
            return true;
        }else{
            this._router.navigate(['/', 'signin']);
        } 
    }
}