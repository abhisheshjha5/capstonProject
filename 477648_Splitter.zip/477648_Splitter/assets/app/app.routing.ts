import { Routes, RouterModule } from "@angular/router";

import { DashboardComponent } from "./common/dashboard.component";
import { SignupComponent } from "./auth/signup.component";
import { SigninComponent } from "./auth/signin.component";
import { LogoutComponent } from "./auth/logout.component";

import { LoggedInAuthGuard } from "./guards/LoggedInAuthGuard";
import { LoginCheckAuthGuard } from "./guards/LoginCheckAuthGuard";
 
const APP_ROUTES: Routes = [
    { path: '', redirectTo: '/signin', pathMatch: 'full' },
    { path: 'home', component: DashboardComponent, canActivate: [LoggedInAuthGuard]}, 
    { path: 'signup', component: SignupComponent, canActivate: [LoginCheckAuthGuard]},
    { path: 'signin', component: SigninComponent, canActivate: [LoginCheckAuthGuard]},
    { path: 'logout', component: LogoutComponent, canActivate: [LoggedInAuthGuard]}
];

export const routing = RouterModule.forRoot(APP_ROUTES);