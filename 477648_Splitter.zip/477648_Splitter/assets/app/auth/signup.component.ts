import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";

import { AuthService } from "./auth.service";
import { Router } from "@angular/router";
import { User } from "./user.model";
import { ErrorService } from "../errors/error.service";
import { Error } from "../errors/error.model";
import { Constants } from "../constants";

import { ServerSuccessResponse } from "./response.model";

@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html'
})
export class SignupComponent implements OnInit {
    signUpForm: FormGroup;

    constructor(private authService: AuthService, private router: Router, private errorService: ErrorService) {}

    onSubmit() {
        const user = new User(
            this.signUpForm.value.email,
            this.signUpForm.value.password,
            this.signUpForm.value.userName
        );
        this.authService.signup(user)
            .subscribe(
                  (result: ServerSuccessResponse) => {
                        if(result && result.message && result.message == Constants.signUpSuccess){
                            this.signUpForm.reset();
                            this.router.navigate(['/', 'signin']);
                        }else{
                            this.errorService.handleError({
                                title: 'Error Ocurred',
                                message: 'User signup failed due to an error'
                            });
                        }
                    },
                    error => {
                        console.log(error);
                        // let respJSON = error.json()
                        // let formattedError: Error = { title: respJSON.title, message: respJSON.error.message };
                        // this.errorService.handleError(formattedError);
                    }
            );
        this.signUpForm.reset();
    }

    ngOnInit() {
        this.signUpForm = new FormGroup({
            userName: new FormControl(null, [Validators.required, Validators.maxLength(20), Validators.minLength(8)]),
            email: new FormControl(null, [Validators.required,
                //TODO add email validation here
                Validators.pattern(Constants.emailValidationRegExp)
            ]),
            password: new FormControl(null, [Validators.required, Validators.minLength(6)])
        });
    }
}