import { Injectable } from "@angular/core";
import { Http, Headers, Response } from "@angular/http";
import 'rxjs/Rx';
import { Observable } from "rxjs";

import { User } from "./user.model";
import { ErrorService } from "../errors/error.service";
import { Error } from "../errors/error.model";
import { ServerSuccessResponse } from "./response.model";

@Injectable()
export class AuthService {
    constructor(private http: Http, private errorService: ErrorService) {}

    _userName: string;

    signup(user: User) {
        const body = JSON.stringify(user);
        const headers = new Headers({'Content-Type': 'application/json'});  
        return this.http.post('http://localhost:3000/user', body, {headers: headers})
            .map((response: Response) => <ServerSuccessResponse> response.json())
            .catch(this._handleError.bind(this));
    }

    signin(user: User) {
        const body = JSON.stringify(user);
        const headers = new Headers({'Content-Type': 'application/json'});
        return this.http.post('http://localhost:3000/user/signin', body, {headers: headers})
            .map((response: Response) => response.json())
            .catch(this._handleError.bind(this));

    }

    setLoggedInUserName(userName: string) {
        this._userName = userName;
    }

    getLoggedInUserName():string {
        return this._userName;
    }

    logout() {
        //TODO add logic to clear localStorage data
        localStorage.removeItem('token');
        localStorage.removeItem('userId');
        localStorage.removeItem('userName');
    }

    isLoggedIn() {
        return localStorage.getItem('token') !== null;
    }

    private _handleError(error: Response): Observable<any>{
        let errorMsg: Error;
        let errorJson = error.json() || {title: 'Error Ocurred', message: 'Unknown Error Ocurred'};
        errorMsg = {title: errorJson.title, message: errorJson.error.message}
        this.errorService.handleError(errorMsg);
        
        return Observable.throw(errorMsg);
    }
}