export class ServerErrorDetails{
    constructor(public errors: any, public message: string, public name?: string){}
}

export class ServerErrorResponse{
    constructor(public title: string, public error: ServerErrorDetails){}
}

export class ServerSuccessResponse{

    constructor(
        public message: string, 
        public addtionalInfo?: any, 
        public token?: string, 
        public userId?: string, 
        public userName?: string
    ){}
}