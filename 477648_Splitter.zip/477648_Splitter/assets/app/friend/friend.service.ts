import { Http, Response, Headers } from "@angular/http";
import { Injectable, EventEmitter } from "@angular/core";
import 'rxjs/Rx';
import { Observable } from "rxjs";

import { Friend } from "./friend.model";
import { ErrorService } from "../errors/error.service";
import { Error } from "../errors/error.model";

@Injectable()
export class FriendService {

    onGetFriendSuccess = new EventEmitter<Friend>();

    public friends: Friend[] = [];

    public selectedFriend: Friend;

    constructor(private http: Http, private errorService: ErrorService) {
    }

    getFriendList(): Friend[] {
        return this.friends;
    }

    setFriendList(friend: Friend) {
        this.friends.push(friend);
    }

    addFriend(friend: Friend) {
        const body = JSON.stringify(friend);
        const headers = new Headers({'Content-Type': 'application/json'});
        const token = localStorage.getItem('token')
            ? '?token=' + localStorage.getItem('token')
            : '';
        return this.http.post('http://localhost:3000/friend' + token, body, {headers: headers})
            //TODO handle response and error here
            .map(response => this.onAddFriendSuccess(response))
			.catch(this._handleError.bind(this));
    }

    onAddFriendSuccess (response) {
        const result = response.json();
        const friend = new Friend(
            result.obj.fName,
            result.obj.lName,
            result.obj.email,
            result.obj.userName,
            result.obj.userId,
            result.obj.message
        );
        return friend;
    }

    getFriends() {
        const headers = new Headers({'Content-Type': 'application/json'});
        const token = localStorage.getItem('token')
            ? '?token=' + localStorage.getItem('token')
            : '';
        return this.http.get('http://localhost:3000/friend'+ token, {headers: headers})
            //TODO handle response and error here
			.map(resp => resp.json().obj)
            .catch(this._handleError.bind(this));
    }

     private _handleError(error: Response): Observable<any>{
        let errorMsg: Error;
        let errorJson = error.json() || {title: 'Error Ocurred', message: 'Unknown Error Ocurred'};
        errorMsg = {title: errorJson.title, message: errorJson.error.message}
        this.errorService.handleError(errorMsg);
        
        return Observable.throw(errorMsg);
    }
}