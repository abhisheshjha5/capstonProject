import { Routes, RouterModule } from "@angular/router";

import { CategoryListComponent } from "./components/category/category-list.component";
import { CheckoutComponent } from "./components/checkout/checkout.component";
import { ProductListComponent } from "./components/product/product-list.component";
import { BasketComponent } from "./components/basket/basket.component";
import { SignupComponent } from "./auth/signup.component";
import { SigninComponent } from "./auth/signin.component";
import { LogoutComponent } from "./auth/logout.component";
import {LoggedInAuthGuard} from "./guards/LoggedInAuthGuard";
import {CanAlwaysActivateGuard} from "./guards/CanAlwaysActivateGuard";
import {CanActivateGuard} from "./guards/CanActivateGuard";
import { LogInCheckAuthGuard } from "./guards/LogInCheckAuthGuard";

const APP_ROUTES: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full', canActivate: [
        LoggedInAuthGuard
    ] },
    { path: 'home', component: CategoryListComponent, canActivate: [
        LoggedInAuthGuard
    ] },
    { path: 'productlist', component: ProductListComponent, canActivate: [
        LoggedInAuthGuard
    ]},
    { path: 'basket', component: BasketComponent, canActivate: [
        LoggedInAuthGuard
    ]},
    { path: 'checkout', component: CheckoutComponent, canActivate: [
        LoggedInAuthGuard
    ]},
    { path: 'signup', component: SignupComponent, canActivate: [
       LogInCheckAuthGuard
    ]},
    { path: 'signin', component: SigninComponent, canActivate: [
        LogInCheckAuthGuard
    ]},
    { path: 'logout', component: LogoutComponent, canActivate: [
       LoggedInAuthGuard
    ] }
];

export const routing = RouterModule.forRoot(APP_ROUTES);