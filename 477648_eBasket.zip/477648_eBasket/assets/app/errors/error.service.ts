import { EventEmitter } from "@angular/core";

import { Error } from "./error.model";

export class ErrorService {
    /**
     * @type {EventEmitter<Error>}
     */
    errorOccurred = new EventEmitter<Error>();

    /**
     * @description emit errorOccurred
     * @param error
     */
    handleError(error: Error) {
        //TODO handle error and emit errorOccurred
        this.errorOccurred.emit(error);
    }
}