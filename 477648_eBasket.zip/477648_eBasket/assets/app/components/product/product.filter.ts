import { Pipe, PipeTransform, Injectable } from '@angular/core';

/**
 * @ProductFilter
 * @description
 * product filter
 */

@Pipe({name: 'pfilter', pure: false })
export class ProductFilter implements PipeTransform {

    /**
     * @override transform method of PipeTransform class
     * @param items
     * @param args
     * @returns {any}
     */
    transform(items: any, args:string): any {
        //TODO return filter product here
        let filter =  args ? args.toLowerCase() : null;
        
        if(items && filter){
             return items.filter(item=> item.name.toLowerCase().indexOf(filter) != -1);
        }else{
            return items;
        }
    }
}