import { Product } from "./product.model";

export class BasketModel{
    constructor (public userId: string, public productList: Product[]){}
}