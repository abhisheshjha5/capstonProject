import { Http, Response, Headers } from "@angular/http";
import { Injectable, EventEmitter } from "@angular/core";
import 'rxjs/Rx';
import { Observable } from "rxjs";
import { Product }  from './product.model';
import { BasketModel } from './basket.model';

import {Error} from "../../errors/error.model";
import {ErrorService} from "../../errors/error.service";

interface iExistingBasketProduct {
    idx?: number,
    product?: Product
}

/**
 * @ProductService
 * @description
 * this service to handle product
 */

@Injectable()
export class ProductService {

    /**
     * @type {string}
     */
    private productsUrl: string = 'data/products.json';

    /**
     * @type {Product[]}
     */
    public products:Product[];

    /**
     * @type {Product[]}
     */
    myBasket: Product[] = [];

    /**
     * @type {string}
     */
    _currntProductType: string = 'fruits';

    /**
     * Constructor for ProductService class
     * @param http
     */
    constructor(private http: Http, private errorService: ErrorService) {
    }

    /**
     * @param type
     */
    setCurrentProductType(type: string ) {
        this._currntProductType = type;
    }

    /**
     * @returns {string}
     */
    getCurrentProductType(): string {
        return this._currntProductType;
    }

    /**
     * @returns {Product[]}
     */
    public getMyBasket(): Product[]{
        let savedProducts: Product[] = [];
        const savedBasket: BasketModel = <BasketModel> JSON.parse(sessionStorage.getItem('basketItems'));
        const loggedUserId = sessionStorage.getItem('userId');
        
        if((savedBasket && loggedUserId) && (savedBasket.userId == loggedUserId)){
           savedProducts = savedBasket.productList; 
        }
        
        return this.myBasket = savedProducts;
    }


    /**
     * @description add product to basket and update basket details
     * @param product
     */
    addProductToBasket(product: Product){
        //TODO add product to basket and update its details
        let addedProducts = this.getMyBasket();
        let existingProduct: iExistingBasketProduct = this.findExistingBasketItem(addedProducts, product);

        if(existingProduct !== undefined && existingProduct.idx !== undefined && existingProduct.product){
            addedProducts[existingProduct.idx].basketCount += 1;
            this.setTotalProductBasketPrice(addedProducts[existingProduct.idx])
        }else{
            product.basketCount = 1;
            this.setTotalProductBasketPrice(product)
            addedProducts.push(product);
        }

        //saving cart in session storage
        this.saveBasketItems(addedProducts);
    }

    /**
     *
     * @returns {number} tCount
     */
    getTotalBasketQuantity(): number {
        //TODO return total basket quantity'
        let totalQty: number = 0;
        //getting basket items
        this.getMyBasket();
        this.myBasket.forEach(item => totalQty += item.basketCount)
        
        return totalQty;
    }

    /**
     * @description reset basket details
     */
    removeBasketItem(item: Product): void {
        //TODO rest basket here
         let basketItems: Product[] = this.getMyBasket();
         let existingProduct: iExistingBasketProduct = this.findExistingBasketItem(this.getMyBasket(), item);

         if(existingProduct.idx !== undefined && existingProduct.product){
            basketItems.splice(existingProduct.idx, 1);
         }

         this.saveBasketItems(basketItems);
    }

    /**
     * @description reset basket details
     */
    resetBasket() {
        //TODO rest basket here
        this.saveBasketItems([]);
    }

    /**
     * @param product
     */
    setTotalProductBasketPrice(product: Product) {
        product.basketPrice = product.basketCount * product.price;
    }

    /**
     * @returns {number}
     */
    getTotalPrice(): number {
        //TODO return total price 
       let totalPrice: number = 0;
        //getting basket items
        this.getMyBasket();
        this.myBasket.forEach(item => totalPrice += item.basketPrice)
        
        return totalPrice;
    }

    /**
     * @returns {Observable<Product[]>}
     */
    getProduct():  Observable <any>{
        //TODO get products from productUrl
        return this.http.get(this.productsUrl)
            .map(resp => this.extractProduct(resp))
            .catch(this.handleError.bind(this))
    }

    /**
     * @param res
     * @returns {Product[]}
     */
    private extractProduct(res: Response): Product[] {
        let body = res.json();
        this.products = body.products || { };
        return this.products;
    }

    /**
     * @param error
     * @returns {ErrorObservable}
     */
    private handleError (error: any):  Observable<any> {
        //TODO handle and show error
        const errorJson = error.json();
        const errorDetails: Error = {title: errorJson.title, message: errorJson.errors.message};
        this.errorService.handleError(errorDetails);

        return Observable.throw(error);
    }

    private findExistingBasketItem (addedProducts: Product[], product: Product): iExistingBasketProduct{
        let existingProduct: iExistingBasketProduct; 
        
        addedProducts.forEach((val, idx) => {
            if(val.id === product.id && val.name == product.name){
                existingProduct = {idx: idx, product: val};
            }
        });

        return existingProduct;
    }

    private saveBasketItems(products: Product[]): void{
        const userId = sessionStorage.getItem('userId');
        const basket: BasketModel = {userId: userId, productList: products};
        
        sessionStorage.setItem('basketItems', JSON.stringify(basket));
    }
}