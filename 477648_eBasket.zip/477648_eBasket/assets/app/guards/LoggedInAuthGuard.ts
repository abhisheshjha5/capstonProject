import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { Router } from "@angular/router";

@Injectable()
export class LoggedInAuthGuard implements CanActivate {

	/**
     * @constructor for LoggedInAuthGuard
     * @param authService
     */
    constructor(private authService: AuthService, private router: Router) {}

	 /**
     * @override canActivate
     * @returns {boolean}
     */
    canActivate() {
        //TODO check if user is logged in or not
        if(this.authService.isLoggedIn())
        {
            return true;
        }else{
            this.router.navigate(['/', 'signin'])
        } 
    }
}