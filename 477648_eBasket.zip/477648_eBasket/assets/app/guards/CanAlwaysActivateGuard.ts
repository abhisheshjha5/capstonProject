import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

import { AuthService } from "../auth/auth.service";

@Injectable()
export class CanAlwaysActivateGuard implements CanActivate {
    constructor(private authService: AuthService){}
	/**
     * override canActivate
     * @returns {boolean}
     */
    canActivate(next: any, state: any): boolean {
        //TODO return  value for routes
        return true;
    }
}