import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { User } from "./user.model";
import { AuthService } from "./auth.service";
import { ErrorService } from "../errors/error.service";
import { Error } from "../errors/error.model";

import { Constants } from "../constants";

@Component({
    selector: 'app-signin',
    templateUrl: './signin.component.html'
})
export class SigninComponent implements OnInit {

    /**
     * @type {FormGroup}
     */
    signInForm: FormGroup;

    /**
     * Constructor for SignInComponent class
     * @param authService
     * @param router
     */
    constructor(private authService: AuthService, private router: Router, private errorService: ErrorService) {}

    /**
     * @name  onSubmit handle signin
     */
    onSubmit() {
        const user = new User(this.signInForm.value.email, this.signInForm.value.password);
        this.authService.signin(user)
            .subscribe(
                //TODO handle response data  and error here 
                result => {
                    if(result.json().token && result.json().userId){
                        sessionStorage.setItem('userId', result.json().userId);
                        sessionStorage.setItem('token', result.json().token);

                        this.router.navigate(['/', 'home'])
                    }else{
                        this.errorService.handleError({title: 'Error Occurred', message: 'Invalid login credentials'})
                    }
                }, 
                error => {
                    let errorJSON = error.json();
                    let formattedError: Error = {title: errorJSON.title, message: errorJSON.error.message};
                    this.errorService.handleError(formattedError);
                }
            );
        this.signInForm.reset();
    }

    /**
     * @name onSignUp navigate to sign up screen
     */
    onSignUp() {
        this.router.navigate(['/', 'signup']);
    }

    /**
     * @override OnInit lifecycle method
     */
    ngOnInit() {
        this.signInForm = new FormGroup({
           password: new FormControl('', [Validators.required, Validators.minLength(6)]),
            email: new FormControl('', [Validators.required, Validators.pattern(Constants.validEmailRegExp)])
        });
    }
}