import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators} from "@angular/forms";

import { AuthService } from "./auth.service";
import { Router } from "@angular/router";
import { User } from "./user.model";
import { ErrorService } from "../errors/error.service";
import { Error } from "../errors/error.model";

import { Constants } from "../constants";

@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html'
})
export class SignupComponent implements OnInit {

    /**
     * @type {FormGroup}
     */
    signUpForm: FormGroup;

    formInvalid:Boolean= false;

    /**
     * Constructor for SignUpComponent class
     * @param authService
     * @param router
     */
    constructor(private authService: AuthService, private router: Router, private errorService: ErrorService) {}

    /**
     * @name  onSubmit handle signup
     */
    onSubmit() {
        const user = new User(
            this.signUpForm.value.email,
            this.signUpForm.value.password,
            this.signUpForm.value.userName
        );

        if(this.signUpForm.valid){
            this.authService.signup(user)
                //TODO handle response and navigate to sign in  and handle error
                .subscribe(
                    result => {
                        let respJSON = result.json();
                        if(respJSON.message && respJSON.message == Constants.signUpSuccess){
                            this.signUpForm.reset();
                            this.router.navigate(['/', 'signin']);
                        }else{
                            this.errorService.handleError({
                                title: 'Error Ocurred',
                                message: 'User signup failed due to an error'
                            });
                        }
                    },
                    error => {
                        let respJSON = error.json()
                        let formattedError: Error = {title: respJSON.title, message: respJSON.error.message};
                        this.errorService.handleError(formattedError);
                    }
                    
            );
            
        }
        else {
            this.formInvalid = true;
        }
    }

    /**
     * @override OnInit lifecycle method
     */
    ngOnInit() {
        this.signUpForm = new FormGroup({
            //TODO add userName, email and password validators here
            userName: new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(20)]),
            password: new FormControl('', [Validators.required, Validators.minLength(6)]),
            email: new FormControl('', [Validators.required, Validators.pattern(Constants.validEmailRegExp)])
        });
    }
}